import SpriteKit

public class GameScene: SKScene {
    var balaozinho: SKSpriteNode =  SKSpriteNode(imageNamed: "balao.png")
    var faca:SKSpriteNode =  SKSpriteNode(imageNamed: "faca.png")
    var pressionado:Bool = false
    public override func sceneDidLoad(){
        self.backgroundColor = .black
        balaozinho.position = CGPoint(x:size.width/2, y: size.height/2)
        balaozinho.setScale(0.2)
        self.addChild(balaozinho)
        
        faca.setScale(0.2)
        faca.physicsBody = SKPhysicsBody(texture: SKTexture(imageNamed:"faca.png"), size:faca.size)
        //O corpo fisico terá o tamanho da faca em px
        
    }
    
    public override func didMove(to view: SKView) {
        
    }
    
    public func gerarFaca()
    {
        if(Int.random(in: 0...100) % 10 == 0)
        {
            let novaFaca:SKSpriteNode = faca.copy() as! SKSpriteNode
            novaFaca.position = CGPoint(x: CGFloat.random(in: 0...size.width), y: size.height + faca.size.height/2)
            addChild(novaFaca)
        }
    }
    
    func touchDown(atPoint pos : CGPoint) {
        let nodestocados = nodes(at: pos)
        if(nodestocados.contains(balaozinho)){
            pressionado = true
            
            
        }
    }
    
    func touchMoved(toPoint pos : CGPoint) {
        if (pressionado){
        balaozinho.position = pos
        }
    }
    
    func touchUp(atPoint pos : CGPoint) {
        
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchDown(atPoint: t.location(in: self)) }
    }
    
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchMoved(toPoint: t.location(in: self)) }
    }
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }
    
    public override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }
    
    public override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        gerarFaca()
    }
}
